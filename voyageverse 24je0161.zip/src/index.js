import {initializeApp} from 'firebase/app'

import{
  getAuth,
  createUserWithEmailAndPassword, 
  signInWithEmailAndPassword,
} from 'firebase/auth'


const firebaseConfig = {
    apiKey: "AIzaSyBEFnEiAY2lq8kKq6k5Xbm0oh069zPlt0Q",
    authDomain: "voyageverse-firebase.firebaseapp.com",
    projectId: "voyageverse-firebase",
    storageBucket: "voyageverse-firebase.firebasestorage.app",
    messagingSenderId: "707490646916",
    appId: "1:707490646916:web:f86e062dbb58a4e1432bd1"
};

initializeApp(firebaseConfig)

const auth = getAuth();
//signingup users
const signupform = document.querySelector(".signin")
signupform.addEventListener("submit", (e) => {
  e.preventDefault()

  const email = signupform.email.value ;
  const password = signupform.password.value;

  createUserWithEmailAndPassword(auth, email, password)
    .then((cred) => {
      console.log("user created:", cred.user);
      signupform.reset()
    })
    .catch((err) => {
      console.log(err.message);
    })
})
// log in 
const loginform = document.querySelector(".login")
loginform.addEventListener("submit", (e) => {
  e.preventDefault()
   const email = loginform.email.value
   const password = loginform.password.value

   signInWithEmailAndPassword(auth,email,password)
    .then((cred) => {
      console.log("user credentials", cred.user);
    })
    .catch((err) => {
      console.log(err.message)
    })
})